package semana14.Arquivo;

public class Numeros {
	public static void main(String[] args) {
		long tempoI=System.currentTimeMillis();
		
		long tempoF=System.currentTimeMillis();
		
		System.out.println(+((tempoF-tempoI)/1000d));
	}

}
