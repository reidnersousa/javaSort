package semana14.Arquivo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class SortRandom {

	public static void main(String[] args) {
		/*
		 * for(int p=0;p<=2000;p++) { System.out.println(","+p); }
		 */
		/*
		 * for(int x=10;x>=0;x--) { System.out.println(","+x); }
		 */

		int cab = 101;
		int it = cab - 1;
		int[] data = geraVetorlRandomBucket(it, cab);
		Vetores valor = new Vetores();
		List<Vetores> listaValor = new ArrayList<Vetores>();
		

		String s2 = "aleat�rio";
		int i = 0;
		int maxVal = cab;
		double num1 = 1;
		double num2 = 2;
		double num3 = 3;
		double num4= 4;
		// sort.setMedia(bolha_mc);
		// listaSort.add(sort);
		i++;
		valor.setValorAle(num1);
		listaValor.add(valor);
		i++;
		valor.setValorCres(num2);
		listaValor.add(valor);
		i++;
		valor.setValorDes(num3);
		listaValor.add(valor);

		System.out.println(i + listaValor.toString());
		
		
		retornaMaisRapido(num1, num2, num3, num4);
		


		/*
		 * int vbc=100; int []cccc=geraVetoresCres(vbc); System.out.println("Antes: " +
		 * Arrays.toString(data)); sortBucket(data, maxVal);
		 * System.out.println("Depois:  " + Arrays.toString(data));
		 * 
		 * System.out.println("Antes: " + Arrays.toString(cccc)); long bolhaini =
		 * System.currentTimeMillis(); sortBucket(cccc, vbc); long bolhafin =
		 * System.currentTimeMillis(); double pric = ((bolhafin - bolhaini) / 1000d);
		 * System.out.println("Depois:  " + Arrays.toString(cccc));
		 * valor.setMedia(pric);
		 */
	}

	/*
	 * public static double Tempo() {
	 * 
	 * 
	 * } long inicioI = System.currentTimeMillis(); sortBucket(vet1a900); long
	 * finalI = System.currentTimeMillis();
	 */

	/*
	
	public static void retornaMais() {
		if (pri < seg & pri < ter & pri < qua) {

			System.out.println("Bolha mais rapido velocidade=" + pri);

		} else if (seg < pri & seg < ter & seg < qua) {

			System.out.println("seg mais rapido velocidade=" + seg);

		} else if (ter < pri & ter < seg & ter < qua) {

			System.out.println("ter mais rapido  velocidade=" + ter);

		} else if (qua < pri & qua < seg & qua < ter) {

			System.out.println("qua mais rapido  velocidade=" + qua);

		}

	
	*/
	
	
	public static void retornaMaisRapido(double pri, double seg, double ter, double qua) {
		if (pri < seg & pri < ter & pri < qua) {

			System.out.println("Bolha mais rapido velocidade=" + pri);

		} else if (seg < pri & seg < ter & seg < qua) {

			System.out.println("seg mais rapido velocidade=" + seg);

		} else if (ter < pri & ter < seg & ter < qua) {

			System.out.println("ter mais rapido  velocidade=" + ter);

		} else if (qua < pri & qua < seg & qua < ter) {

			System.out.println("qua mais rapido  velocidade=" + qua);

		}

	}

	public static double Vmenor(double pri, double seg, double ter, double qua) {
		double maior = 0, menor = 10;
		double aux;
		double n[] = { pri, seg, ter, qua };

		for (int i = 0; i < 4; i++) {
			aux = n[i];
			if (menor > aux) {
				menor = n[i];

			}
			if (maior < aux) {
				maior = n[i];
			}

		}

		System.out.println("mais lentor= " + maior + "mais rapidor =" + menor);
		return menor;
	}

	public static void sortBucket(int[] a, int maxVal) {
		int[] bucket = new int[maxVal + 1];

		for (int i = 0; i < bucket.length; i++) {
			bucket[i] = 0;
		}

		for (int i = 0; i < a.length; i++) {
			bucket[a[i]]++;
		}

		int outPos = 0;
		for (int i = 0; i < bucket.length; i++) {
			for (int j = 0; j < bucket[i]; j++) {
				a[outPos++] = i;
			}
		}
	}

	public static int[] geraVetorlRandomBucket(int n, int numA) {
		int[] v = new int[n];
		Random gerador = new Random();
		for (int i = 0; i < n; i++) {
			v[i] = gerador.nextInt(numA);
		}
		return v;
	}

	public static int[] geraVetoresDesc(int numeros) {
		// vet1a900.length - 1
		int[] valores = new int[numeros];
		int tam;
		tam = valores.length;
		System.out.println(tam);

		for (int lil = 0; lil < tam/* 9 */; lil++) {
			valores[lil] = numeros--;

		}
		return valores;
	}

	public static int[] geraVetoresCres(int numeros) {
		int[] valores = new int[numeros];

		for (int lil = 0; lil < numeros; lil++) {
			valores[lil] = lil;

		}
		return valores;
	}

}
