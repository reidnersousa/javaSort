package semana14.Arquivo;

import javax.swing.JFileChooser;

public class CaixaDialogo {

	public static void main(String[] args) {
		// Abrir arquivo
		JFileChooser jf = new JFileChooser();// Objeto para dialogo
		jf.showOpenDialog(null);//Abrir arquivo
		// jf.showSaveDialog(null);//Salvar arquivo

	}
	//  \\Users\\Wilson\\lerArquivo\\arq2.txt
}
