package semana14.Arquivo;

public class Vetores {
	private String sort; 
	private double valorCres;
	private double valorDes;
	private double valorAle;
	
	
	@Override
	public String toString() {
		return "Vetores [sort=" + sort + ", valorCres=" + valorCres + ", valorDes=" + valorDes + ", valorAle="
				+ valorAle + "]";
	}
	
	
	
	
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public double getValorCres() {
		return valorCres;
	}
	public void setValorCres(double valorCres) {
		this.valorCres = valorCres;
	}
	public double getValorDes() {
		return valorDes;
	}
	public void setValorDes(double valorDes) {
		this.valorDes = valorDes;
	}
	public double getValorAle() {
		return valorAle;
	}
	public void setValorAle(double valorAle) {
		this.valorAle = valorAle;
	}
	
	

}
