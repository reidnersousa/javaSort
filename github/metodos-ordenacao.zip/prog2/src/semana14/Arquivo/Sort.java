package semana14.Arquivo;

import java.util.Arrays;
import java.util.Random;

public class Sort {

	public static void main(String[] args) {

		
		int vbc=10000; // valor em cres pro bucket
		int []cccc=geraVetoresCres(vbc);
		
		int vb=10000; /// valor descres pro bucket
		int []llll=geraVetoresDesc(vb);	
		
		int cab=10001; // valor Random pro bucket 
		int it=cab-1;
		int[] data = geraVetorlRandomBucket(it,cab);
		int maxVal = cab;
		
		
		int[] vet1a900 = geraVetoresCres(10000);

		int[] vet900a1 = geraVetoresDesc(10000);  

		
		int[] random = geraVetorRandom(10000);
		
		int[] testqq = { 1, 3, 2, 5, 6, 4, 8 };
		int[] m = { 4, 6, 7, 3, 5, 1, 2, 8 };
		int[] w = new int[m.length];
		int[] mp = new int[vet1a900.length];
		int[] mpr = new int[random.length];

	
		/************************************ **********************************
		 ********************************CRESCENTE ********** *************************88
		 ********************************************************************/
		long inicioI = System.currentTimeMillis();
		insertionSort(vet1a900);
		long finalI = System.currentTimeMillis();
		
		
		long inicioB = System.currentTimeMillis();
		bolha(vet1a900);
		long finalB = System.currentTimeMillis();
		
		long inicioss = System.currentTimeMillis();
		selectionSort(vet1a900);
		long finalss = System.currentTimeMillis();
		
		
		long inicioqs = System.currentTimeMillis();
		sortBucket(cccc, vbc);
		long finalqs = System.currentTimeMillis();
		

		double pric = ((finalI - inicioI) / 1000d);
		double segc = ((finalB - inicioB) / 1000d);
		double terc = ((finalss - inicioss) / 1000d);
		double quac = ((finalqs - inicioqs) / 1000d);
		
		System.out.println();
		System.out.println("VELOCIDADE COM ORDEM CRESCENTE");
		System.out.println();
		System.out.println("Tempo da Insertion por ordem crescente      de 1a10000  =" + pric);
		System.out.println("Tempo da Bolha  por ordem crescente         de 1a10000  =" + segc);
		System.out.println("Tempo do selectionSort  por ordem crescente de 1a10000  =" + terc);
		System.out.println("Tempo do Bucket    por ordem crescente      de 1a10000  =" + quac);

		
		
		Vmenor(pric, segc, terc, quac);
		//System.out.println("\n CRESCENTE  pri=" + pric + ", seg=" + segc + ",ter=" + terc + ",qua=" + quac);

		

		/***************************************************************************************************************
		 ************************************* Descrescente************************************************************************
		 **********************************************************************************************************/
		

		
		long inicioId = System.currentTimeMillis();
		insertionSort(vet900a1);
		long finalId = System.currentTimeMillis();
				
		long inicioBd = System.currentTimeMillis();
		bolha(vet900a1);
		long finalBd = System.currentTimeMillis();
		
		long iniciossd = System.currentTimeMillis();
		selectionSort(vet900a1);
		long finalssd = System.currentTimeMillis();
		
		
		long inicioqsd = System.currentTimeMillis();
		sortBucket(llll, vb);
		long finalqsd = System.currentTimeMillis();
		
		double prid = ((finalId - inicioId) / 1000d);
		double segd = ((finalBd - inicioBd) / 1000d);
		double terd = ((finalssd - iniciossd) / 1000d);
		double quad = ((finalqsd - inicioqsd) / 1000d);

		System.out.println();
		System.out.println("VELOCIDADE COM ORDEM DESCRESCENTE");
		System.out.println();
		System.out.println("Tempo da Insertion por ordem descrescente      de 10000a1  =" + prid);
		System.out.println("Tempo da Bolha  por ordem descrescente         de 10000a1  =" + segd);
		System.out.println("Tempo do selectionSort  por ordem descrescente de 10000a1  =" + terd);
		System.out.println("Tempo do Bucket por ordem descrescente         de 10000a1  =" + quad);

		Vmenor(prid, segd, terd, quad);
		//System.out.println("\n DESCRESCENTE  pri  =" + prid + ", seg=" + segd + ",ter=" + terd + ",qua=" + quad);
		

		/***************************************************************************************************************
		 ************************************************ RANDOM************************************************************
		 **********************************************************************************************************/
		
		long inicioIr = System.currentTimeMillis();
		insertionSort(random);
		long finalIr = System.currentTimeMillis();
		// System.out.println(Arrays.toString(vet1a900));

		
		long inicioBr = System.currentTimeMillis();
		bolha(random);
		long finalBr = System.currentTimeMillis();
		
		long iniciossr = System.currentTimeMillis();
		selectionSort(random);
		long finalssr = System.currentTimeMillis();
		
		// System.out.println(Arrays.toString(vet1a900));
		long inicioqsr = System.currentTimeMillis();
		sortBucket(data, maxVal);
		long finalqsr = System.currentTimeMillis();
		

		double pri = ((finalIr - inicioIr) / 1000d); // Insertion
		double seg = ((finalBr - inicioBr) / 1000d); // Bolha
		double ter = ((finalssr - iniciossr) / 1000d); // selectionSort
		double qua = ((finalqsr - inicioqsr) / 1000d); // MergeSort

		System.out.println();
		System.out.println("VELOCIDADE COM ORDEM ALEATORIA ");
		System.out.println();
		System.out.println("Tempo da Insertion por ordem aleatoria       =" + pri);
		System.out.println("Tempo da Bolha  por ordem aleatoria          =" + seg);
		System.out.println("Tempo do selectionSort  por ordem aleatoria  =" + ter);
		System.out.println("Tempo do Bucket    por ordem aleatoria       =" + qua);

		//System.out.println("\n ALEATORIO pri=" + pri + ",seg=" + seg + ",ter=" + ter + ",qua=" + qua);
		Vmenor(pri, seg, ter, qua);
		
	}

	public static double Vmenor(double pri, double seg, double ter, double qua) {
		double maior = 0, menor = 10;
		double aux;
		double n[] = { pri, seg, ter, qua };

		for (int i = 0; i < 4; i++) {
			aux = n[i];
			if (menor > aux) {
				menor = n[i];

			}
			if (maior < aux) {
				maior = n[i];
			}

		}

		System.out.println("mais lentor= " + maior + "mais rapidor =" + menor);
		return menor;
	}

	public static int[] geraVetoresCres(int numeros) {
		int[] valores = new int[numeros];

		for (int lil = 0; lil < numeros; lil++) {
			valores[lil] = lil;

		}
		return valores;
	}

	public static int[] geraVetoresDesc(int numeros) {
		// vet1a900.length - 1
		int[] valores = new int[numeros];
		int tam;
		tam = valores.length;
		System.out.println(tam);

		for (int lil = 0; lil < tam/* 9 */; lil++) {
			valores[lil] = numeros--;

		}
		return valores;
	}

	public static int[] geraVetorRandom(int n) {
		int[] v = new int[n];
		Random gerador = new Random();
		for (int i = 0; i < n; i++) {
			v[i] = gerador.nextInt(10000);
		}
		return v;
	}

	public static void bolha(int[] v) {
		for (int ultimo = v.length - 1; ultimo > 0; ultimo--) {
			for (int i = 0; i < ultimo; i++) {
				if (v[i] > v[i + 1]) {
					trocar(v, i, i + 1);
				}
			}
		}

	}

	private static void trocar(int[] vb, int ib, int jb) {
		int auxb = vb[ib];
		vb[ib] = vb[jb];
		vb[jb] = auxb;
	}

	// quicksort nao funciona
	public static void quicksort(int[] vq, int esqq, int dir) {
		if (esqq < dir) {
			int jq = seperar(vq, esqq, dir);
			quicksort(vq, esqq, jq - 1);
			quicksort(vq, jq + 1, dir);
		}
	}

	private static int seperar(int[] vqq, int esqq, int dirq) {
		int iiq = esqq + 1;
		int jjq = dirq;
		int pivoq = vqq[esqq];
		while (iiq <= jjq) {
			if (vqq[iiq] <= pivoq) {
				iiq++;
			} else if (vqq[jjq] > pivoq) {
				jjq--;
			} else if (iiq <= jjq) {
				trocarqs(vqq, iiq, jjq);
				iiq++;
				jjq--;
			}

		}
		trocarqs(vqq, esqq, jjq);
		return 0;
	}

	private static void trocarqs(int[] vt, int it, int jt) {
		int auxt = vt[it];
		vt[it] = vt[jt];
		vt[jt] = auxt;
	}
	// quicksort

	public static void insertionSort(int[] valorI) {
		int x, jj;
		for (int i = 1; i < valorI.length; i++) {
			x = valorI[i];
			jj = i - 1;
			while ((jj >= 0) && valorI[jj] > x) {
				valorI[jj + 1] = valorI[jj];
				jj = jj - 1;
			}
			valorI[jj + 1] = x;

		}
	}

	public static void selectionSort(int[] vss) {
		for (int iss = 0; iss < vss.length; iss++) {
			int menorvss = iss;
			for (int jss = iss + 1; jss < vss.length; jss++) {
				if (vss[jss] < vss[menorvss]) {
					menorvss = jss;
				}
				trocarss(vss, iss, menorvss);
			}
		}

	}

	private static void trocarss(int vst[], int ivs, int menorvst) {
		int auxvs = vst[ivs];
		vst[ivs] = vst[menorvst];
		vst[menorvst] = auxvs;
	}

	private static void mergeSort(int[] m, int[] ww, int ini, int fim) {
		if (ini < fim) {
			int meio = (ini + fim) / 2;
			mergeSort(m, ww, ini, meio);
			mergeSort(m, ww, meio + 1, fim);
			intercalar(m, ww, ini, meio, fim);
		}
	}

	private static void intercalar(int[] m, int[] ww, int ini, int meio, int fim) {
		for (int kk = ini; kk <= fim; kk++) {
			ww[kk] = m[kk];

		}
		int im = ini;
		int jm = meio + 1;

		for (int kk = ini; kk <= fim; kk++) {
			if (im > meio)
				m[kk] = ww[jm++];
			else if (jm > fim)
				m[kk] = ww[im++];
			else if (ww[im] < ww[jm])
				m[kk] = ww[im++];
			else
				m[kk] = ww[jm++];

		}
	}
	
	
	public static void sortBucket(int[] a, int maxVal) {
		int[] bucket = new int[maxVal + 1];

		for (int i = 0; i < bucket.length; i++) {
			bucket[i] = 0;
		}

		for (int i = 0; i < a.length; i++) {
			bucket[a[i]]++;
		}

		int outPos = 0;
		for (int i = 0; i < bucket.length; i++) {
			for (int j = 0; j < bucket[i]; j++) {
				a[outPos++] = i;
			}
		}
	}
	public static int[] geraVetorlRandomBucket(int n,int numA) {
		int[] v = new int[n];
		Random gerador = new Random();
		for (int i = 0; i < n; i++) {
			v[i] = gerador.nextInt(numA);
		}
		return v;
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
