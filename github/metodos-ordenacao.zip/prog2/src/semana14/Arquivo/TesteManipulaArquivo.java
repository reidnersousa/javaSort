package semana14.Arquivo;

import java.util.List;

public class TesteManipulaArquivo {

	public static void main(String[] args) {
		/*String path="\\Users\\Wilson\\lerArquivo\\CriandoArquivos";
		try {
			String resposta =ManipulaArquivo.criarDiretorio(path);
			System.out.println(resposta);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		*/
		/**
		String path="\\Users\\Wilson\\lerArquivo\\CriandoArquivos//criaArq1.txt";
		try {
			String resposta =ManipulaArquivo.criarArquivo(path);
			System.out.println(resposta);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		**/
		/*
		String path="\\Users\\Wilson\\lerArquivo";
		try {
			ManipulaArquivo.listarArquivo(path);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		*/
		/****
		String path="\\Users\\Wilson\\lerArquivo\\arq2.txt";
		try {
			ManipulaArquivo.lerArquivo(path);
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		****/
		String path1="\\Users\\Wilson\\lerArquivo\\arq2.txt";
		String path2="\\Users\\Wilson\\lerArquivo\\arquivo1.txt";

		try {
			List<String> dados=ManipulaArquivo.lerArquivoEDevolverLista(path1);
			ManipulaArquivo.gravarArquivo(dados, path2);
			System.out.println("Feito");
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
}
