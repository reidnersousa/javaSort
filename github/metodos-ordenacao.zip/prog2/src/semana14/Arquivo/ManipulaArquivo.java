package semana14.Arquivo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ManipulaArquivo {
	public static String criarDiretorio(String path) throws IOException {
		// Criando um objeto File
		File f = new File(path);
		if (!f.exists()) {
			f.mkdir();
			return "Diret�rio criado com sucesso.";
		} else {
			return "Diret�rio j� existe.";
		}
	}

	public static String criarArquivo(String arquivo) throws IOException {
		File f = new File(arquivo);
		if (!f.exists()) {
			f.createNewFile();
			return "Arquivo criado com sucesso.";
		} else {
			return "Arquivo j� existe";

		}
	}

	public static void listarArquivo(String path) throws IOException {
		File dir = new File(path);
		for (File arq : dir.listFiles()) {
			if (arq.isFile()) {
				System.out.println(arq.getName());
			}
		}
	}

	public static void lerArquivo(String arq) throws IOException {
		// Criar um leitor de arquivo
		BufferedReader br = new BufferedReader(new FileReader(arq));
		while (br.ready()) {
			String linha = br.readLine();
			System.out.println(linha);
		}
		br.close();
	}
	
	// criando lerDiretorio esta na aula 3 se nao tive esta na aula 2 
	
	public static  List<String> lerArquivoEDevolverLista(String arq) throws IOException {
		// Criar um leitor de arquivo
		BufferedReader br = new BufferedReader(new FileReader(arq));
		List<String>dados= new ArrayList<String>();
		while (br.ready()) {
			String linha = br.readLine();
			dados.add(linha);
			
		}
		br.close();
		return dados;
	}

	public static void gravarArquivo(List<String> dados, String arq) throws IOException {
		// Criar um gravador de dados
		FileWriter fw = new FileWriter(arq, true);// ele recebe o nome do arquivo
		// se voc� coloca true aqui e arquivo existir ele nao apagar o arquivo ele mantem e adionar
		// se voce coloca false ele apagar o arquivo que existir e criar um novo
		
		BufferedWriter bw = new BufferedWriter(fw);
		for (String s : dados) {
			bw.append(s);
			bw.newLine();
		}
		bw.close();
	}

}
