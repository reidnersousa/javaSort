package semana14.Arquivo;

import java.util.Random;

public class Pessoa {
	
	private Double valor1;
	private Double valor2;
	private Double valor3;
	private Double  media;
	
	
	
	
	
	
	


	
	
	@Override
	public String toString() {
		return "Pessoa [valor1=" + valor1 + ", valor2=" + valor2 + ", valor3=" + valor3 + ", media=" + media + "]";
	}

	public Double getValor1() {
		return valor1;
	}

	public void setValor1(Double valor1) {
		this.valor1 = valor1;
	}

	public Double getValor2() {
		return valor2;
	}

	public void setValor2(Double valor2) {
		this.valor2 = valor2;
	}

	public Double getValor3() {
		return valor3;
	}

	public void setValor3(Double valor3) {
		this.valor3 = valor3;
	}

	public Double getMedia() {
		return media;
	}

	public void setMedia(Double media) {
		this.media = media;
	}

	public static double Vmenor(double pri, double seg, double ter, double qua) {
		double maior = 0, menor = 10;
		double aux;
		double n[] = { pri, seg, ter, qua };

		for (int i = 0; i < 4; i++) {
			aux = n[i];
			if (menor > aux) {
				menor = n[i];

			}
			if (maior < aux) {
				maior = n[i];
			}

		}

		System.out.println("mais lentor= " + maior + "mais rapidor =" + menor);
		return menor;
	}
	/*
	public static int[] geraVetoresCres(int numeros) {
		int[] valores = new int[numeros];

		for (int lil = 0; lil < numeros; lil++) {
			valores[lil] = lil;

		}
		return valores;
	}
	*/

	public static int[] geraVetoresDesc(int numeros) {
		// vet1a900.length - 1
		int[] valores = new int[numeros];
		int tam;
		tam = valores.length;
		System.out.println(tam);

		for (int lil = 0; lil < tam/* 9 */; lil++) {
			valores[lil] = numeros--;

		}
		return valores;
	}

	public static int[] geraVetorRandom(int n) {
		int[] v = new int[n];
		Random gerador = new Random();
		for (int i = 0; i < n; i++) {
			v[i] = gerador.nextInt(10000);
		}
		return v;
	}

	public static void bolha(int[] v) {
		for (int ultimo = v.length - 1; ultimo > 0; ultimo--) {
			for (int i = 0; i < ultimo; i++) {
				if (v[i] > v[i + 1]) {
					trocar(v, i, i + 1);
				}
			}
		}

	}

	private static void trocar(int[] vb, int ib, int jb) {
		int auxb = vb[ib];
		vb[ib] = vb[jb];
		vb[jb] = auxb;
	}

	// quicksort nao funciona
	public static void quicksort(int[] vq, int esqq, int dir) {
		if (esqq < dir) {
			int jq = seperar(vq, esqq, dir);
			quicksort(vq, esqq, jq - 1);
			quicksort(vq, jq + 1, dir);
		}
	}

	private static int seperar(int[] vqq, int esqq, int dirq) {
		int iiq = esqq + 1;
		int jjq = dirq;
		int pivoq = vqq[esqq];
		while (iiq <= jjq) {
			if (vqq[iiq] <= pivoq) {
				iiq++;
			} else if (vqq[jjq] > pivoq) {
				jjq--;
			} else if (iiq <= jjq) {
				trocarqs(vqq, iiq, jjq);
				iiq++;
				jjq--;
			}

		}
		trocarqs(vqq, esqq, jjq);
		return 0;
	}

	private static void trocarqs(int[] vt, int it, int jt) {
		int auxt = vt[it];
		vt[it] = vt[jt];
		vt[jt] = auxt;
	}
	// quicksort

	public static void insertionSort(int[] valorI) {
		int x, jj;
		for (int i = 1; i < valorI.length; i++) {
			x = valorI[i];
			jj = i - 1;
			while ((jj >= 0) && valorI[jj] > x) {
				valorI[jj + 1] = valorI[jj];
				jj = jj - 1;
			}
			valorI[jj + 1] = x;

		}
	}

	public static void selectionSort(int[] vss) {
		for (int iss = 0; iss < vss.length; iss++) {
			int menorvss = iss;
			for (int jss = iss + 1; jss < vss.length; jss++) {
				if (vss[jss] < vss[menorvss]) {
					menorvss = jss;
				}
				trocarss(vss, iss, menorvss);
			}
		}

	}

	private static void trocarss(int vst[], int ivs, int menorvst) {
		int auxvs = vst[ivs];
		vst[ivs] = vst[menorvst];
		vst[menorvst] = auxvs;
	}

	private static void mergeSort(int[] m, int[] ww, int ini, int fim) {
		if (ini < fim) {
			int meio = (ini + fim) / 2;
			mergeSort(m, ww, ini, meio);
			mergeSort(m, ww, meio + 1, fim);
			intercalar(m, ww, ini, meio, fim);
		}
	}

	private static void intercalar(int[] m, int[] ww, int ini, int meio, int fim) {
		for (int kk = ini; kk <= fim; kk++) {
			ww[kk] = m[kk];

		}
		int im = ini;
		int jm = meio + 1;

		for (int kk = ini; kk <= fim; kk++) {
			if (im > meio)
				m[kk] = ww[jm++];
			else if (jm > fim)
				m[kk] = ww[im++];
			else if (ww[im] < ww[jm])
				m[kk] = ww[im++];
			else
				m[kk] = ww[jm++];

		}
	}
	
	
	public static void sortBucket(int[] a, int maxVal) {
		int[] bucket = new int[maxVal + 1];

		for (int i = 0; i < bucket.length; i++) {
			bucket[i] = 0;
		}

		for (int i = 0; i < a.length; i++) {
			bucket[a[i]]++;
		}

		int outPos = 0;
		for (int i = 0; i < bucket.length; i++) {
			for (int j = 0; j < bucket[i]; j++) {
				a[outPos++] = i;
			}
		}
	}

}
