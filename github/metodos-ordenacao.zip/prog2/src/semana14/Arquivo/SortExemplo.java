package semana14.Arquivo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

// aqui e o tester ><><><><><>
public class SortExemplo {

	public static void main(String[] args) {
		inserirPessoa();

	}

	public static void inserirPessoa() {

		Scanner sc = new Scanner(System.in);
		Vetores bolha = new Vetores();
		Vetores insertion = new Vetores();
		Vetores selection = new Vetores();
		Vetores bucket = new Vetores();
		// Pessoa sort;
		// List<Vetores> listaSort = new ArrayList<Vetores>();

		List<Vetores> listBolha = new ArrayList<Vetores>();
		List<Vetores> listInsertion = new ArrayList<Vetores>();
		List<Vetores> listSelection = new ArrayList<Vetores>();
		List<Vetores> listBucket = new ArrayList<Vetores>();

		int opcao = 0;
		int crescenteValor = 0;
		int vbc = 9000;
		int vbd = 9000;

		int[] vetorcrescente = geraVetoresCres(vbc);
		int[] vetordescrescente = geraVetoresDesc(vbd);
		int[] vetoraleatorio = geraVetorRandom(9000);

		int cab = 9001; // valor Random pro bucket
		int it = cab - 1;
		int[] data = geraVetorlRandomBucket(it, cab);
		int maxVal = cab;
		int quantasVezFiz=0;
		
		String s1 = " ";
		String s2 = " ";

		do {

			quantasVezFiz++;
			System.out.println("Escolha uma das op��es abaixo");
			System.out.println("Op��o 1 - Escolha um Sort");
			System.out.println("Op��o 2 - Imprime pessoas cadastradas");
			System.out.println("Op��o 0 - Sair do programa");
			System.out.println("_______________________");

			System.out.print("Digite aqui sua op��o: ");
			opcao = Integer.parseInt(sc.nextLine());

			if (opcao == 1) {

				System.out.println("Escolha uma das op��es abaixo ");
				System.out.println("Op��o bolha - Faz uma ordena��o Bolha");
				System.out.println("Op��o insertion -Faz uma ordena��o de Insertion");
				System.out.println("Op��o selection -Faz uma ordena��o de selection");
				System.out.println("Op��o Bucket    -Faz uma ordena��o de Bucket");
				System.out.println("_______________________");

				System.out.print("Digite o Sort");
				s1 = sc.nextLine();
				

				System.out.println("Escolha uma das op��es abaixo ");
				System.out.println("Op��o crescente    -Faz uma ordena��o crescente");
				System.out.println("Op��o descrescente -Faz uma ordena��o descrescente");
				System.out.println("Op��o aleat�rio    -Faz uma ordena��o aleat�rio");
				System.out.println("_______________________");
				System.out.print("Digite a Ordem ");
				s2 = sc.nextLine();

				if (s1.toLowerCase().equals("bolha")) {
					System.out.println("Faz algo bolha ");
					bolha.setSort("bolha");
					listBolha.add(bolha);

					
					if (s2.toLowerCase().equals("crescente")) {
						System.out.println("Antes: " + Arrays.toString(vetorcrescente));

						long bolhainic = System.currentTimeMillis();
						bolha(vetorcrescente);
						long bolhafinc = System.currentTimeMillis();
						double bolha_mc = ((bolhafinc - bolhainic) / 1000d);
						bolha.setValorCres(bolha_mc);
						listBolha.add(bolha);

						System.out.println("Depois " + Arrays.toString(vetorcrescente));

					}

					else if (s2.toLowerCase().equals("descrescente")) {
						System.out.println("Antes: " + Arrays.toString(vetordescrescente));

						long bolhainid = System.currentTimeMillis();
						bolha(vetordescrescente);
						long bolhafind = System.currentTimeMillis();
						double bolha_md = ((bolhafind - bolhainid) / 1000d);
						bolha.setValorDes(bolha_md);
						listBolha.add(bolha);

						System.out.println("Depois " + Arrays.toString(vetordescrescente));
					}

					else if (s2.toLowerCase().equals("aleatorio") | s2.toLowerCase().equals("aleat�rio")) {
						System.out.println("Antes: " + Arrays.toString(vetoraleatorio));

						long bolhainia = System.currentTimeMillis();
						bolha(vetoraleatorio);
						long bolhafina = System.currentTimeMillis();
						double bolha_ma = ((bolhafina - bolhainia) / 1000d);
						bolha.setValorAle(bolha_ma);
						listBolha.add(bolha);

						System.out.println("Depois " + Arrays.toString(vetoraleatorio));
					} else
						System.out.println("Erro ao digita digite novamente ");
				}

				else if (s1.toLowerCase().equals("insertion")) {
					System.out.println("Faz algo insertion");
					insertion.setSort("insertion");
					listInsertion.add(insertion);


					if (s2.toLowerCase().equals("crescente")) {
						System.out.println("Antes: " + Arrays.toString(vetorcrescente));
						long insinic = System.currentTimeMillis();
						insertionSort(vetorcrescente);
						long insfimc = System.currentTimeMillis();
						double inserC = ((insfimc - insinic) / 1000d);
						insertion.setValorCres(inserC);
						listInsertion.add(insertion);
						System.out.println("Depois " + Arrays.toString(vetorcrescente));
					} else if (s2.toLowerCase().equals("descrescente")) {
						System.out.println("Antes: " + Arrays.toString(vetordescrescente));
						long insinid = System.currentTimeMillis();
						insertionSort(vetordescrescente);
						long insfimd = System.currentTimeMillis();
						double inserD = ((insfimd - insinid) / 1000d);
						insertion.setValorDes(inserD);
						listInsertion.add(insertion);
						System.out.println("Depois " + Arrays.toString(vetordescrescente));
					} else if (s2.toLowerCase().equals("aleatorio") | s2.toLowerCase().equals("aleat�rio")) {
						System.out.println("Antes: " + Arrays.toString(vetoraleatorio));
						long insinia = System.currentTimeMillis();
						insertionSort(vetoraleatorio);
						long insfima = System.currentTimeMillis();
						double inserA = ((insfima - insinia) / 1000d);
						insertion.setValorAle(inserA);
						listInsertion.add(insertion);

						System.out.println("Depois " + Arrays.toString(vetoraleatorio));
					} else
						System.out.println("Erro ao digita digite novamente ");

				} else if (s1.toLowerCase().equals("selection")) {
					System.out.println("Faz algo selection");
					selection.setSort("selection");
					listSelection.add(selection);

					
					if (s2.toLowerCase().equals("crescente")) {
						System.out.println("Antes: " + Arrays.toString(vetorcrescente));

						long selecinic = System.currentTimeMillis();
						selectionSort(vetorcrescente);
						long selecfimc = System.currentTimeMillis();
						double selecC = ((selecfimc - selecinic) / 1000d);
						selection.setValorCres(selecC);
						listSelection.add(selection);

						System.out.println("Depois " + Arrays.toString(vetorcrescente));
					} else if (s2.toLowerCase().equals("descrescente")) {
						System.out.println("Antes: " + Arrays.toString(vetordescrescente));
						long selecinid = System.currentTimeMillis();
						selectionSort(vetordescrescente);
						long selecfimd = System.currentTimeMillis();
						double selecD = ((selecfimd - selecinid) / 1000d);
						selection.setValorDes(selecD);
						listSelection.add(selection);

						System.out.println("Depois " + Arrays.toString(vetordescrescente));
					} else if (s2.toLowerCase().equals("aleatorio") | s2.toLowerCase().equals("aleat�rio")) {
						System.out.println("Antes: " + Arrays.toString(vetoraleatorio));
						long selecinia = System.currentTimeMillis();
						selectionSort(vetoraleatorio);
						long selecfima = System.currentTimeMillis();
						double selecA = ((selecfima - selecinia) / 1000d);
						selection.setValorAle(selecA);
						listSelection.add(selection);
						System.out.println("Depois " + Arrays.toString(vetoraleatorio));
					} else
						System.out.println("Erro ao digita digite novamente ");

				} else if (s1.toLowerCase().equals("bucket")) {
					System.out.println("Faz algo bucket");
					bucket.setSort("bucket");
					listBucket.add(bucket);

					if (s2.toLowerCase().equals("crescente")) {
						System.out.println("Antes: " + Arrays.toString(vetorcrescente));

						long bucketinic = System.currentTimeMillis();

						sortBucket(vetorcrescente, vbc);
						long bucketfimc = System.currentTimeMillis();
						double bucketc = ((bucketfimc - bucketinic) / 1000d);
						bucket.setValorCres(bucketc);
						listBucket.add(bucket);
						System.out.println("Depois " + Arrays.toString(vetorcrescente));
					} else if (s2.toLowerCase().equals("descrescente")) {
						System.out.println("Antes: " + Arrays.toString(vetordescrescente));
						long bucketinid = System.currentTimeMillis();

						sortBucket(vetordescrescente, vbd);
						long bucketfimd = System.currentTimeMillis();
						double bucketd = ((bucketfimd - bucketinid) / 1000d);
						bucket.setValorDes(bucketd);
						listBucket.add(bucket);

						System.out.println("Depois " + Arrays.toString(vetordescrescente));
					} else if (s2.toLowerCase().equals("aleatorio") | s2.toLowerCase().equals("aleat�rio")) {
						System.out.println("Antes: " + Arrays.toString(data));
						long bucketinia = System.currentTimeMillis();
						sortBucket(data, maxVal);
						long bucketfima = System.currentTimeMillis();
						double bucketa = ((bucketfima - bucketinia) / 1000d);
						bucket.setValorAle(bucketa);
						listBucket.add(bucket);
						System.out.println("Depois " + Arrays.toString(data));
					} else
						System.out.println("Erro ao digita o tipo de ordem . Por digite  novamente ");
				} else
					System.out.println("Erro ao digita  o Sort .Por favor digite novamente><><>< ");

			}

			/*
			 * 
			 * aluno.setCodigo(Integer.parseInt(sc.nextLine()));
			 * 
			 * System.out.print("Digite o nome: "); aluno.setNome(sc.nextLine());
			 */
			/*
			 * if(contador==1) { aluno.setInteger(8.9); System.out.println();
			 * listaAlunos.add(aluno); } if(contador==2) { aluno.setInteger(6.5);
			 * System.out.println(); listaAlunos.add(aluno); } if(contador==3) {
			 * aluno.setInteger(7.2); System.out.println(); listaAlunos.add(aluno); }
			 * if(contador>3) { aluno.setInteger(null); System.out.println();
			 * listaAlunos.add(aluno); }
			 */
			// System.out.println();
			// listaAlunos.add(aluno);

			// }
			else if (opcao == 2) {
				 if (listBolha.isEmpty()||listInsertion.isEmpty()) {

				//if (listBolha.isEmpty() || listInsertion.isEmpty() || listSelection.isEmpty() || listBucket.isEmpty()) {

					System.out.println("N�o existem pessoas cadastradas, pressione uma tecla para continuar!");
					sc.nextLine();
				} else {
					System.out.println(quantasVezFiz);
					System.out.println(listBolha.toString());
					System.out.println(listInsertion.toString());
					System.out.println(listSelection.toString());
					System.out.println(listBucket.toString());
					System.out.println("Pressione um tecla para continuar.");
					sc.nextLine();
				}
			}

		} while (opcao != 0);

		sc.close();

	}

	public static void bolha(int[] v) {
		for (int ultimo = v.length - 1; ultimo > 0; ultimo--) {
			for (int i = 0; i < ultimo; i++) {
				if (v[i] > v[i + 1]) {
					trocar(v, i, i + 1);
				}
			}
		}

	}

	private static void trocar(int[] vb, int ib, int jb) {
		int auxb = vb[ib];
		vb[ib] = vb[jb];
		vb[jb] = auxb;
	}

	public static void insertionSort(int[] valorI) {
		int x, jj;
		for (int i = 1; i < valorI.length; i++) {
			x = valorI[i];
			jj = i - 1;
			while ((jj >= 0) && valorI[jj] > x) {
				valorI[jj + 1] = valorI[jj];
				jj = jj - 1;
			}
			valorI[jj + 1] = x;

		}
	}

	public static void selectionSort(int[] vss) {
		for (int iss = 0; iss < vss.length; iss++) {
			int menorvss = iss;
			for (int jss = iss + 1; jss < vss.length; jss++) {
				if (vss[jss] < vss[menorvss]) {
					menorvss = jss;
				}
				trocarss(vss, iss, menorvss);
			}
		}

	}

	private static void trocarss(int vst[], int ivs, int menorvst) {
		int auxvs = vst[ivs];
		vst[ivs] = vst[menorvst];
		vst[menorvst] = auxvs;
	}

	public static void sortBucket(int[] a, int maxVal) {
		int[] bucket = new int[maxVal + 1];

		for (int i = 0; i < bucket.length; i++) {
			bucket[i] = 0;
		}

		for (int i = 0; i < a.length; i++) {
			bucket[a[i]]++;
		}

		int outPos = 0;
		for (int i = 0; i < bucket.length; i++) {
			for (int j = 0; j < bucket[i]; j++) {
				a[outPos++] = i;
			}
		}
	}

	public static int[] geraVetorlRandomBucket(int n, int numA) {
		int[] v = new int[n];
		Random gerador = new Random();
		for (int i = 0; i < n; i++) {
			v[i] = gerador.nextInt(numA);
		}
		return v;
	}

	public static int[] geraVetoresCres(int numeros) {
		int[] valores = new int[numeros];

		for (int lil = 0; lil < numeros; lil++) {
			valores[lil] = lil;

		}
		return valores;
	}

	public static int[] geraVetoresDesc(int numeros) {
		// vet1a900.length - 1
		int[] valores = new int[numeros];
		int tam;
		tam = valores.length;
		System.out.println(tam);

		for (int lil = 0; lil < tam/* 9 */; lil++) {
			valores[lil] = numeros--;

		}
		return valores;
	}

	public static void retornaMaisRapido(double pri, double seg, double ter, double qua) {
		if (pri < seg & pri < ter & pri < qua) {

			System.out.println("Bolha mais rapido velocidade=" + pri);

		} else if (seg < pri & seg < ter & seg < qua) {

			System.out.println("seg mais rapido velocidade=" + seg);

		} else if (ter < pri & ter < seg & ter < qua) {

			System.out.println("ter mais rapido  velocidade=" + ter);

		} else if (qua < pri & qua < seg & qua < ter) {

			System.out.println("qua mais rapido  velocidade=" + qua);

		}

	}

	public static int[] geraVetorRandom(int n) {
		int[] v = new int[n];
		Random gerador = new Random();
		for (int i = 0; i < n; i++) {
			v[i] = gerador.nextInt(10000);
		}
		return v;
	}

}
