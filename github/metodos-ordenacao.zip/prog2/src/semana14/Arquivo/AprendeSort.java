package semana14.Arquivo;

import semana14.Arquivo.SortExemplo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JOptionPane;

import prog2.semana06.CursoTeste;
import semana13.Atividade.AlunoList;

public class AprendeSort {
	public static void main(String[] args) {
		inserirPessoa();

	}

	public static void inserirPessoa() {

		Scanner sc = new Scanner(System.in);
		Pessoa sort;
		List<Pessoa> listaSort = new ArrayList<Pessoa>();

		int opcao = 0;
		int crescenteValor = 0;
		int vbc=100;
		int vbd=100;
		
		
		int[] vetorcrescente = geraVetoresCres(vbc);
		int[] vetordescrescente  = geraVetoresDesc(vbd);
		int[] vetoraleatorio = geraVetorRandom(100);
		
		int cab=101; // valor Random pro bucket 
		int it=cab-1;
		int[] data = geraVetorlRandomBucket(it,cab);
		int maxVal = cab;
		
		
		
		
		
		String s1 = " ";
		String s2 = " ";

		do {

			System.out.println("Escolha uma das op��es abaixo");
			System.out.println("Op��o 1 - Escolha um Sort");
			System.out.println("Op��o 2 - Imprime pessoas cadastradas");
			System.out.println("Op��o 0 - Sair do programa");
			System.out.println("_______________________");

			System.out.print("Digite aqui sua op��o: ");
			opcao = Integer.parseInt(sc.nextLine());

			if (opcao == 1) {

				System.out.print("Digite o Sort");
				s1 = sc.nextLine();
				System.out.print("Digite a Ordem ");
				s2 = sc.nextLine();

				if (s1.toLowerCase().equals("bolha")) {
					System.out.println("Faz algo bolha ");
					if (s2.toLowerCase().equals("crescente")) {
						System.out.println("Antes: " + Arrays.toString(vetorcrescente ));
						bolha(vetorcrescente);
						System.out.println("Depois " + Arrays.toString(vetorcrescente ));
					}
					else if(s2.toLowerCase().equals("descrescente")) {
						System.out.println("Antes: " + Arrays.toString(vetordescrescente ));
						bolha(vetordescrescente);
						System.out.println("Depois " + Arrays.toString(vetordescrescente ));
					}
					else if (s2.toLowerCase().equals("aleatorio")) {
						System.out.println("Antes: " + Arrays.toString(vetoraleatorio));
						bolha(vetoraleatorio);
						System.out.println("Depois " + Arrays.toString(vetoraleatorio));
					}
					else
						System.out.println("Erro ao digita digite novamente ");
				}

				else if (s1.toLowerCase().equals("insertion")) {
					System.out.println("Faz algo insertion");
					
					if (s2.toLowerCase().equals("crescente")) {
						System.out.println("Antes: " + Arrays.toString(vetorcrescente ));
						insertionSort(vetorcrescente);
						System.out.println("Depois " + Arrays.toString(vetorcrescente ));
					}
					else if (s2.toLowerCase().equals("descrescente")) {
						System.out.println("Antes: " + Arrays.toString(vetordescrescente ));
						insertionSort(vetordescrescente);
						System.out.println("Depois " + Arrays.toString(vetordescrescente ));
					}
					else if (s2.toLowerCase().equals("aleatorio")) {
						System.out.println("Antes: " + Arrays.toString(vetoraleatorio));
						insertionSort(vetoraleatorio);
						System.out.println("Depois " + Arrays.toString(vetoraleatorio));
					}
					else
						System.out.println("Erro ao digita digite novamente ");
					

				} else if (s1.toLowerCase().equals("selection")) {
					System.out.println("Faz algo selection");
					if (s2.toLowerCase().equals("crescente")) {
						System.out.println("Antes: " + Arrays.toString(vetorcrescente ));
						selectionSort(vetorcrescente);
						System.out.println("Depois " + Arrays.toString(vetorcrescente ));
					}
					else if (s2.toLowerCase().equals("descrescente")) {
						System.out.println("Antes: " + Arrays.toString(vetordescrescente ));
						selectionSort(vetordescrescente);
						System.out.println("Depois " + Arrays.toString(vetordescrescente ));
					}
					else if (s2.toLowerCase().equals("aleatorio")) {
						System.out.println("Antes: " + Arrays.toString(vetoraleatorio));
						selectionSort(vetoraleatorio);
						System.out.println("Depois " + Arrays.toString(vetoraleatorio));
					}
					else
						System.out.println("Erro ao digita digite novamente ");
					
				} else if (s1.toLowerCase().equals("bucket")) {
					System.out.println("Faz algo bucket");
					
					if (s2.toLowerCase().equals("crescente")) {
						System.out.println("Antes: " + Arrays.toString(vetorcrescente ));
						
						sortBucket(vetorcrescente,vbc);
						System.out.println("Depois " + Arrays.toString(vetorcrescente ));
					}
					else if (s2.toLowerCase().equals("descrescente")) {
						System.out.println("Antes: " + Arrays.toString(vetordescrescente ));
						sortBucket(vetordescrescente,vbd);
						System.out.println("Depois " + Arrays.toString(vetordescrescente ));
					}
					else if (s2.toLowerCase().equals("aleatorio")) {
						System.out.println("Antes: " + Arrays.toString(data));
						sortBucket(data, maxVal);
						System.out.println("Depois " + Arrays.toString(data));
					}
					else
						System.out.println("Erro ao digita o tipo de ordem . Por digite  novamente ");
				}
				else
				System.out.println("Erro ao digita  o Sort .Por favor digite novamente><><>< ");

			}
			
			/*
			 * 
			 * aluno.setCodigo(Integer.parseInt(sc.nextLine()));
			 * 
			 * System.out.print("Digite o nome: "); aluno.setNome(sc.nextLine());
			 */
			/*
			 * if(contador==1) { aluno.setInteger(8.9); System.out.println();
			 * listaAlunos.add(aluno); } if(contador==2) { aluno.setInteger(6.5);
			 * System.out.println(); listaAlunos.add(aluno); } if(contador==3) {
			 * aluno.setInteger(7.2); System.out.println(); listaAlunos.add(aluno); }
			 * if(contador>3) { aluno.setInteger(null); System.out.println();
			 * listaAlunos.add(aluno); }
			 */
			// System.out.println();
			// listaAlunos.add(aluno);
			/*
			 * } else if (opcao == 2) { if (listaAlunos.isEmpty()) { System.out.
			 * println("N�o existem pessoas cadastradas, pressione uma tecla para continuar!"
			 * ); sc.nextLine(); } else { System.out.println(listaAlunos.toString());
			 * 
			 * System.out.println("Pressione um tecla para continuar."); sc.nextLine(); } }
			 */
		} while (opcao != 0);

		sc.close();

	}

	public static void bolha(int[] v) {
		for (int ultimo = v.length - 1; ultimo > 0; ultimo--) {
			for (int i = 0; i < ultimo; i++) {
				if (v[i] > v[i + 1]) {
					trocar(v, i, i + 1);
				}
			}
		}

	}

	private static void trocar(int[] vb, int ib, int jb) {
		int auxb = vb[ib];
		vb[ib] = vb[jb];
		vb[jb] = auxb;
	}
	
	
	
	
	public static void insertionSort(int[] valorI) {
		int x, jj;
		for (int i = 1; i < valorI.length; i++) {
			x = valorI[i];
			jj = i - 1;
			while ((jj >= 0) && valorI[jj] > x) {
				valorI[jj + 1] = valorI[jj];
				jj = jj - 1;
			}
			valorI[jj + 1] = x;

		}
	}

	public static void selectionSort(int[] vss) {
		for (int iss = 0; iss < vss.length; iss++) {
			int menorvss = iss;
			for (int jss = iss + 1; jss < vss.length; jss++) {
				if (vss[jss] < vss[menorvss]) {
					menorvss = jss;
				}
				trocarss(vss, iss, menorvss);
			}
		}

	}

	private static void trocarss(int vst[], int ivs, int menorvst) {
		int auxvs = vst[ivs];
		vst[ivs] = vst[menorvst];
		vst[menorvst] = auxvs;
	}
	
	public static void sortBucket(int[] a, int maxVal) {
		int[] bucket = new int[maxVal + 1];

		for (int i = 0; i < bucket.length; i++) {
			bucket[i] = 0;
		}

		for (int i = 0; i < a.length; i++) {
			bucket[a[i]]++;
		}

		int outPos = 0;
		for (int i = 0; i < bucket.length; i++) {
			for (int j = 0; j < bucket[i]; j++) {
				a[outPos++] = i;
			}
		}
	}
	public static int[] geraVetorlRandomBucket(int n,int numA) {
		int[] v = new int[n];
		Random gerador = new Random();
		for (int i = 0; i < n; i++) {
			v[i] = gerador.nextInt(numA);
		}
		return v;
	}
	
	
	public static int[] geraVetoresCres(int numeros) {
		int[] valores = new int[numeros];

		for (int lil = 0; lil < numeros; lil++) {
			valores[lil] = lil;

		}
		return valores;
	}

	public static int[] geraVetoresDesc(int numeros) {
		// vet1a900.length - 1
		int[] valores = new int[numeros];
		int tam;
		tam = valores.length;
		System.out.println(tam);

		for (int lil = 0; lil < tam/* 9 */; lil++) {
			valores[lil] = numeros--;

		}
		return valores;
	}

	public static int[] geraVetorRandom(int n) {
		int[] v = new int[n];
		Random gerador = new Random();
		for (int i = 0; i < n; i++) {
			v[i] = gerador.nextInt(10000);
		}
		return v;
	}

	
	
	
	
}
